#!/bin/bash

# Sugerencia de Cristian: usar funciones en el shellscript
menuListado () {
    echo -e "\033[1;30m---------------------\033[0m"
    echo -e "\033[1;30m|Listado de usuarios|\033[0m"
    echo -e "\033[1;30m---------------------\033[0m"
    echo -e "\033[1;30m1)Todos los usuarios\033[0m"
    echo -e "\033[1;30m2)Equipo tecnico\033[0m"
    echo -e "\033[1;30m3)Encargados de base de datos\033[0m"
    echo -e "\033[1;30m4)Encargado de seguridad\033[0m"
    echo -e "\033[1;30m5)Administradores\033[0m"
    echo -e "\033[1;30m0)Atrás\033[0m"
    read -p "$(echo -e "\033[1;30mIngrese una opción (1-5):\033[0m")" opcion
    case $opcion in
        1)
            
            ;;
        2)
            ;;
        3)
            ;;
        4)
            ;;
        0)
            exit
            ;;
        *)
            # USAR COLOR ROJO
            echo -e "\033[1;30m Opción inválida. Debe escribir 1,2,3,4 o 0 \033[0m"
            menuListado
            ;;
    esac
    
}

clear
menuListado

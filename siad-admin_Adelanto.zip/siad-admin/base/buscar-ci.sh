#!/bin/bash
ci=$1
#Encripto la cedula
ci_encriptada=$(echo -n $ci | md5sum | awk '{print $1;}')

fila=$(grep $ci_encriptada /etc/siad-usuarios)

if [ -n "$fila" ]; then
    
    nombre=$(echo $fila | awk -F: '{print $3;}')
    contacto=$(echo $fila | awk -F: '{print $4;}')
    correo=$(echo $fila | awk -F: '{print $5;}')
    rol=$(echo $fila | awk -F: '{print $6;}')

    echo "Nombre: $nombre"
    echo "Nombre de usuario: $nomusuario"
    echo "Nro. de contacto: $contacto"
    echo "Correo electrónico: $correo"
    echo "Rol: $rol"
    exit 0
else
    exit 1
fi


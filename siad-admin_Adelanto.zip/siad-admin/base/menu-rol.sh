#!/bin/bash

echo -e "\033[1;30mSeleccione el rol\033[0m"
echo -e "\033[1;30m-----------------\033[0m"
echo -e "\033[1;30m 1) Administrador\033[0m"
echo -e "\033[1;30m 2) Equipo tecnico\033[0m"
echo -e "\033[1;30m 3) Encargado de base de datos\033[0m"
echo -e "\033[1;30m 4) Encargado de seguridad\033[0m"
echo -e "\033[1;30m 5) Encargado de Diseño web\033[0m"
read -p  "$(echo -e "\033[1;30m Ingrese una opción (1-5): \033[0m")" opcionrol



#!/bin/bash
clear
echo -e "\033[1;30m-----------------\033[0m"
echo -e "\033[1;30m| Baja de usuarios |\033[0m"
echo -e "\033[1;30m------------------\033[0m"

read -p "$(echo -e "\033[1;30m Escriba el nombre de usuario (o enter para cancelar): \033[0m")" nusuario
read -p "$(echo -e "\033[1;30m ¿Está seguro de que desea eliminar a Martín Vignolo? (s/n): \033[0m")"

echo ""
echo -e "\033[1;30m No existe ningún usuario mvignolo. \033[0m"
read -p "$(echo -e "\033[1;30m Presione enter para continuar. \033[0m")"


#!/bin/bash
nomusuario=$1

userdel $nomusuario

sed -i "/$nomusuario/d" /etc/siad-usuarios


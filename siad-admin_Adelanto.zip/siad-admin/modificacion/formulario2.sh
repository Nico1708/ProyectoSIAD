#!/bin/bash
clear
nusuario=$1
echo -e "\033[1;30mModificación del usuario\033[0m" $nusuario
echo -e "\033[1;30m-------------------------\033[0m"
echo -e "\033[1;30mPresione enter para mantener el dato actual o escriba el dato que desea sustituir.\033[0m"
echo ""
read -p "$(echo -e "\033[1;30mNúmero de contacto (1234567):\033[0m")" ncontacto
read -p "$(echo -e "\033[1;30mCorreo electrónico (usuario@dominio.com):\033[0m")"  correo
read -p "$(echo -e "\033[1;30mRol (equipo técnico) ¿Cambiar? (s/n) \033[0m")"  cambiarrol
read -p "$(echo -e "\033[1;30m¿Reiniciar contraseña? (s/n) \033[0m")" cambiarpassword


#!/bin/bash
clear

echo -e "\033[1;30m----------------------------\033[0m"
echo -e "\033[1;30m| Modificación de usuarios |\033[0m"
echo -e "\033[1;30m----------------------------\033[0m"

read -p "$(echo -e "\033[1;30mIngrese el nombre de usuario (dejar en blanco para volver atrás):\033[0m") " nusuario
read -p "$(echo -e "\033[1;30mIngrese la cedula (dejar en blanco para volver atrás):\033[0m") " cedula

echo ""
echo -e "\033[1;30mNo hay ningún usuario registrado con el nombre mvignolo.\033[0m"
echo -e "\033[1;30mEscriba nuevamente.\033[0m"
read -p "$(echo -e "\033[1;30mIngrese el nombre de usuario (dejar en blanco para volver atrás):\033[0m") "

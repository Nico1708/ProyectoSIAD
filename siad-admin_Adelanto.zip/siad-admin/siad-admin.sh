#!/bin/bash

borrarpantalla=1

# Sugerencia de Cristian: usar funciones en el shellscript
menuPrincipal () {
    if test $borrarpantalla = 1
    then
        clear
    fi
    borrarpantalla=1
    # Elegir un color más luminoso
    echo -e "\033[1;30m---------------------------\033[0m"
    echo -e "\033[1;30m|Administración de usuarios|\033[0m"
    echo -e "\033[1;30m----------------------------\033[0m"
    echo -e "\033[1;30m 1)Alta de usuarios\033[0m"
    echo -e "\033[1;30m 2)Listado de usuarios\033[0m"
    echo -e "\033[1;30m 3)Modificación de usuarios\033[0m"
    echo -e "\033[1;30m 4)Baja de usuarios\033[0m"
    echo -e "\033[1;30m 0)Salir\033[0m"
    read -p "$(echo -e "\033[1;30m Ingrese una opción:\033[0m ")" opcion

    case $opcion in
        1)
            alta/formulario-alta.sh
            ;;
        2)
            consultas/submenu-consultas.sh
            ;;
        3)
            modificacion/formulario1.sh
            ;;
        4)
            baja/formulario-baja.sh
            ;;
        0)
            clear
            exit
            ;;
        *)
            # USAR COLOR ROJO
            echo -e "\033[1;30m Opción inválida. Debe escribir 1,2,3,4 o 0 \033[0m"
            borrarpantalla=0
            ;;
    esac
    menuPrincipal
}

menuPrincipal

#!/bin/bash
nomusuario=$1
ci=$2
nombre=$3
contacto=$4
correo=$5
rol=$6

sudo useradd $nomusuario

echo "$nomusuario:$(echo -n $ci | md5sum | awk '{print $1;}'):$nombre:$contacto:$correo:$rol" >> /etc/siad-usuarios
sudo passwd $nomusuario

sudo usermod -aG $rol $nomusuario

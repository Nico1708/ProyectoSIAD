#!/bin/bash

clear
echo -e "\033[1;30m Ya hay un usuario con la cédula 12345678 en el sistema.\033[0m"
        echo -e "\033[1;30m Nombre: Martín Vignolo\033[0m"
	echo -e "\033[1;30m Nro. de contacto: 43688645\033[0m"
	echo -e "\033[1;30m Correo electrónico: martinvignolo@gmail.com\033[0m"
	echo -e "\033[1;30m Rol: administrador\033[0m"
echo 
echo -e "\033[1;30m 1)Actualizar información\033[0m"
echo -e "\033[1;30m 2)Reiniciar contraseña\033[0m"
echo -e "\033[1;30m 0)Volver atrás\033[0m"
read -p "$(echo -e "\033[1;30m Ingrese una opción:\033[0m")" opcion

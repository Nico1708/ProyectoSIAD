#!/bin/bash

menuRol () {
	# Este código aparece duplicado en el formulario de alta y en el formulario de
	# modificación por corrección de la primera entrega

	echo -e "\033[1;30mSeleccione el rol\033[0m"
	echo -e "\033[1;30m-----------------\033[0m"
	echo -e "\033[1;30m 1) Administrador\033[0m"
	echo -e "\033[1;30m 2) Equipo tecnico\033[0m"
	echo -e "\033[1;30m 3) Encargado de base de datos\033[0m"
	echo -e "\033[1;30m 4) Encargado de seguridad\033[0m"
	echo -e "\033[1;30m 5) Encargado de Diseño web\033[0m"
	read -p  "$(echo -e "\033[1;30m Ingrese una opción (1-5): \033[0m")" opcionrol
	case $opcionrol in
	1)
		rol=administrador
	;;
	2)
		rol=equipo-tecnico
	;;
	3)
		rol=encargado-bd
	;;
	4)
	    rol=encargado-seguridad
	;;
	5)
	    rol=encargado-diseno-web
	;;
	*)
	    echo "Opción inválida. Ingrese nuevamente"
	    menuRol
	;;
	esac
}

clear
echo -e "\033[1;30m--------------------\033[0m"
echo -e "\033[1;30m| Alta de usuarios |\033[0m"
echo -e "\033[1;30m--------------------\033[0m"
read -p "$(echo -e "\033[1;30m Nombre de usuario: \033[0m")" nomusuario
read -p "$(echo -e "\033[1;30m Nro de cédula: \033[0m")" ci
read -p "$(echo -e "\033[1;30m Nombre: \033[0m")" nombre
read -p "$(echo -e "\033[1;30m Nro de contacto: \033[0m")" contacto
read -p "$(echo -e "\033[1;30m Correo electrónico: \033[0m")" correo
rol=indef
menuRol

alta/crear-usuario.sh $nomusuario $ci $nombre $contacto $correo $rol

#!/bin/bash

clear
nusuario=$1
#Provisorio
#pasar por parametro "persona", o "nopersona"
tipo=$2

echo Ya hay un usuario con el nombre $nusuario en el sistema.

# Si el usuario es una persona
if [ "$tipo" = "persona" ]; then
	echo -e "\033[1;30m Nombre: Martín Vignolo\033[0m"
	echo -e "\033[1;30m Nro. de contacto: 43688645\033[0m"
	echo -e "\033[1;30m Correo electrónico: martinvignolo@gmail.com\033[0m"
	echo -e "\033[1;30m Rol: administrador\033[0m"
	echo ""
	echo -e "\033[1;30m1)Elegir otro nombre de usuario\033[0m"
	echo -e "\033[1;30m2)Actualizar información de mvignolo\033[0m"
	echo -e "\033[1;30m3)Reiniciar contraseña de mvignolo\033[0m"
	echo -e "\033[1;30m0)Volver atrás\033[0m"
	read -p "$(echo -e "\033[1;30m Ingrese una opción: \033[0m")" opcion
else
	# Si el usuario no es una persona
	read -p "$(echo -e "\033[1;30m Ingrese otro nombre de usuario: \033[0m")" opcion
fi
